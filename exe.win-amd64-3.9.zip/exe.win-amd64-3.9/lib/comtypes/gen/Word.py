from comtypes.gen import _00020905_0000_0000_C000_000000000046_0_8_7
globals().update(_00020905_0000_0000_C000_000000000046_0_8_7.__dict__)
__name__ = 'comtypes.gen.Word'