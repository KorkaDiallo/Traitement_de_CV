from comtypes.gen import _2DF8D04C_5BFA_101B_BDE5_00AA0044DE52_0_2_8
globals().update(_2DF8D04C_5BFA_101B_BDE5_00AA0044DE52_0_2_8.__dict__)
__name__ = 'comtypes.gen.Office'